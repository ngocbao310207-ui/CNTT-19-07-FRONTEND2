function calculateBMI() {
  const height = Number(document.getElementById("height").value);
  const weight = Number(document.getElementById("weight").value);
  const result = document.getElementById("result");

  if (!height || !weight || height <= 0 || weight <= 0) {
    result.innerHTML = "Dữ liệu không hợp lệ";
    result.className = "red";
    return;
  }

  const bmi = (weight / (height * height)).toFixed(2);

  let category = "";
  let color = "";

  if (bmi < 18.5) {
    category = "Gầy";
    color = "blue";
  } else if (bmi < 25) {
    category = "Bình thường";
    color = "green";
  } else if (bmi < 30) {
    category = "Thừa cân";
    color = "orange";
  } else {
    category = "Béo phì";
    color = "red";
  }

  result.className = color;
  result.innerHTML = `BMI: ${bmi} - ${category}`;
}