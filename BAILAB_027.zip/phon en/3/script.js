let secretNumber;
let count;
let maxNumber;
let maxTurns;

startGame();

function startGame() {

  maxNumber = Number(
    document.getElementById("level").value
  );

  secretNumber =
    Math.floor(Math.random() * maxNumber) + 1;

  count = 0;

  maxTurns = 10;

  document.getElementById("count").innerText = count;

  document.getElementById("remain").innerText = maxTurns;

  document.getElementById("history").innerHTML = "";

  document.getElementById("message").innerHTML = "";

  document.getElementById("guide").innerHTML =
    `Hãy đoán số từ 1 - ${maxNumber}`;

  console.log("Secret:", secretNumber);
}

function guessNumber() {

  const input =
    document.getElementById("guessInput");

  const value = Number(input.value);

  const message =
    document.getElementById("message");

  const history =
    document.getElementById("history");

  // VALIDATE

  if (!value || value < 1 || value > maxNumber) {

    message.className = "error";

    message.innerHTML =
      `Vui lòng nhập số từ 1 - ${maxNumber}`;

    return;
  }

  count++;
  maxTurns--;

  document.getElementById("count").innerText = count;

  document.getElementById("remain").innerText = maxTurns;

  // LỊCH SỬ

  const li = document.createElement("li");

  li.innerText = `Lần ${count}: ${value}`;

  history.appendChild(li);

  // KIỂM TRA

  if (value < secretNumber) {

    message.className = "warning";

    message.innerHTML =
      "📉 Số bạn đoán nhỏ hơn đáp án";

  } else if (value > secretNumber) {

    message.className = "warning";

    message.innerHTML =
      "📈 Số bạn đoán lớn hơn đáp án";

  } else {

    message.className = "success";

    message.innerHTML =
      `🎉 Chính xác sau ${count} lần đoán`;

    disableGame();

    return;
  }

  // THUA

  if (maxTurns === 0) {

    message.className = "error";

    message.innerHTML =
      `❌ Bạn đã thua. Đáp án là ${secretNumber}`;

    disableGame();
  }

  input.value = "";
}

function disableGame() {

  document.getElementById("guessInput").disabled = true;
}

function resetGame() {

  document.getElementById("guessInput").disabled = false;

  document.getElementById("guessInput").value = "";

  startGame();
}

// ĐỔI LEVEL

document.getElementById("level")
  .addEventListener("change", resetGame);