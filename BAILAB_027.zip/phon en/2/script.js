function calculateOrder() {

  const amount = Number(
    document.getElementById("amount").value
  );

  const member =
    document.getElementById("member").value;

  const coupon =
    document.getElementById("coupon").value;

  const result =
    document.getElementById("result");
  if (!amount || amount <= 0) {
    result.innerHTML =
      "<p style='color:red'>Vui lòng nhập đơn hàng hợp lệ</p>";
    return;
  }
  let discountPercent = 0;
  if (amount >= 5000000) {
    discountPercent = 15;
  } else if (amount >= 2000000) {
    discountPercent = 10;
  } else if (amount >= 1000000) {
    discountPercent = 5;
  }
  if (member === "gold") {
    discountPercent += 5;
  } else if (member === "silver") {
    discountPercent += 2;
  }
  let discountMoney =
    amount * discountPercent / 100;
  let couponMoney = 0;
  if (coupon === "SAVE50") {
    couponMoney = 50000;
  } else if (coupon === "SAVE100") {
    couponMoney = 100000;
  }
  let shipping = 30000;
  if (amount >= 3000000) {
    shipping = 0;
  }

  const final =
    amount - discountMoney - couponMoney + shipping;
  result.innerHTML = `
    <p><strong>Tiền gốc:</strong>
      ${amount.toLocaleString()} VNĐ
    </p>
    <p><strong>Giảm giá:</strong>
      ${discountPercent}%
    </p>
    <p><strong>Tiền giảm:</strong>
      ${discountMoney.toLocaleString()} VNĐ
    </p>
    <p><strong>Mã giảm:</strong>
      ${couponMoney.toLocaleString()} VNĐ
    </p>
    <p><strong>Phí vận chuyển:</strong>
      ${shipping.toLocaleString()} VNĐ
    </p>
    <hr>
    <h3 style="color:green">
      Thanh toán:
      ${final.toLocaleString()} VNĐ
    </h3>
  `;
}