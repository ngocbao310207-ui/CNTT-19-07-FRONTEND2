const scores = [8, 7, 9, 6, 10];

const total = scores.reduce((sum, score) => sum + score, 0);
const avg = total / scores.length;

let rank = "";

if (avg < 5) rank = "Yếu";
else if (avg < 7) rank = "Trung bình";
else if (avg < 8.5) rank = "Khá";
else rank = "Giỏi";

console.log("Danh sách điểm:", scores);
console.log("Điểm TB:", avg.toFixed(2));
console.log("Xếp loại:", rank);