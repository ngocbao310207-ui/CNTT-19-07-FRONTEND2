const API_URL = "https://6a15722691ff9a63de082983.mockapi.io/api/v1/sinhviendnu"

function hienThiDanhSachSinhVien(danhSach) {
  const danhSachElement = document.getElementById("danhSach");

  if (!danhSachElement) {
    return;
  }

  danhSachElement.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Họ Tên</th>
          <th>Mã Sinh Viên</th>
          <th>Giới Tính</th>
          <th>Ngày Sinh</th>
          <th>Điểm</th>
          <th>Xếp Loại</th>
        </tr>
      </thead>
      <tbody>
        ${danhSach
          .map(function (sinhVien) {
            // Xử lý ngày sinh
            const ngaySinh = sinhVien.ngay_sinh 
              ? new Date(sinhVien.ngay_sinh).toLocaleDateString('vi-VN')
              : "Chưa có";
            
            // Xử lý điểm và phân loại
            const diem = sinhVien.diem || 0;
            let xepLoai = "";
            let classXepLoai = "";
            
            if (diem >= 70) {
              xepLoai = "Giỏi";
              classXepLoai = "gioi";
            } else if (diem >= 50) {
              xepLoai = "Bình Thường";
              classXepLoai = "binh-thuong";
            } else {
              xepLoai = "Kém";
              classXepLoai = "kem";
            }

            return `
              <tr>
                <td>${sinhVien.id}</td>
                <td>${sinhVien.ho_ten || "Chưa có tên"}</td>
                <td>${sinhVien.ma_sinh_vien || "Chưa có mã"}</td>
                <td>${sinhVien.gioi_tinh ? "Nữ" : "Nam"}</td>
                <td>${ngaySinh}</td>
                <td class="diem">${diem}</td>
                <td><span class="xep-loai ${classXepLoai}">${xepLoai}</span></td>
              </tr>
            `;
          })
          .join("")}
      </tbody>
    </table>
  `;
}

async function laySinhVien() {
  const response = await fetch(API_URL);

  if (!response.ok) {
    throw new Error("Không thể lấy danh sách sinh viên");
  }

  const data = await response.json();
  console.log("Danh sách sinh viên:", data);
  hienThiDanhSachSinhVien(data);
  return data;
}

async function layMotSinhVien(id) {
  const response = await fetch(`${API_URL}/${id}`);

  if (!response.ok) {
    throw new Error(`Không thể lấy sinh viên có id = ${id}`);
  }

  const data = await response.json();
  console.log("Một sinh viên:", data);
  return data;
}

async function themMotSinhVien(sinhVienMoi) {
  const response = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(sinhVienMoi),
  });

  if (!response.ok) {
    throw new Error("Không thể thêm sinh viên");
  }

  const data = await response.json();
  console.log("Đã thêm sinh viên:", data);
  return data;
}

async function capNhatSinhVien(id, thongTinMoi) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(thongTinMoi),
  });

  if (!response.ok) {
    throw new Error(`Không thể cập nhật sinh viên có id = ${id}`);
  }

  const data = await response.json();
  console.log("Đã cập nhật sinh viên:", data);
  return data;
}

async function xoaSinhVien(id) {
  const response = await fetch(`${API_URL}/${id}`, {
    method: "DELETE",
  });

  if (!response.ok) {
    throw new Error(`Không thể xóa sinh viên có id = ${id}`);
  }

  const data = await response.json();
  console.log("Đã xóa sinh viên:", data);
  return data;
}

laySinhVien();
layMotSinhVien(1);